// =====================================
// FORMULARIO DE CITAS
// =====================================

const citaForm = document.querySelector('#citas form');

if (citaForm) {

    citaForm.addEventListener('submit', function (e) {

        e.preventDefault();

        const nombre =
            citaForm.querySelector('[name="nombre"]').value;

        const telefono =
            citaForm.querySelector('[name="telefono"]').value;

        const email =
            citaForm.querySelector('[name="email"]').value;

        const tratamiento =
            citaForm.querySelector('[name="tratamiento"]').value;

        const fecha =
            citaForm.querySelector('[name="fecha"]').value;

        const hora =
            citaForm.querySelector('[name="hora"]').value;

        const mensaje = `
Hola, deseo reservar una cita en OrthoNova Clínica Dental.

DATOS DEL PACIENTE

Nombre: ${nombre}
Teléfono: ${telefono}
Correo: ${email}

TRATAMIENTO

${tratamiento}

FECHA Y HORA

Fecha: ${fecha}
Hora: ${hora}
        `;

        const whatsappUrl =
            `https://wa.me/51952694710?text=${encodeURIComponent(mensaje)}`;

        window.open(whatsappUrl, '_blank');

        setTimeout(() => {
            citaForm.submit();
        }, 500);
    });
}


// =====================================
// ANIMACIÓN DE TARJETAS AL HACER SCROLL
// =====================================

const animatedCards = document.querySelectorAll(
    '.card, .doctor-card, .testimonial'
);

const observer = new IntersectionObserver(
    (entries) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.style.opacity = '1';

                entry.target.style.transform =
                    'translateY(0)';

                observer.unobserve(entry.target);
            }
        });
    },
    {
        threshold: 0.15
    }
);

animatedCards.forEach((card) => {

    card.style.opacity = '0';

    card.style.transform =
        'translateY(30px)';

    card.style.transition =
        'all 0.6s ease';

    observer.observe(card);
});


// =====================================
// EFECTO SUAVE PARA EL MENÚ
// =====================================

document.querySelectorAll('nav a').forEach(link => {

    link.addEventListener('click', function (e) {

        const targetId =
            this.getAttribute('href');

        if (targetId.startsWith('#')) {

            e.preventDefault();

            const target =
                document.querySelector(targetId);

            if (target) {

                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});


// =====================================
// BOTÓN WHATSAPP ANIMADO
// =====================================

const whatsappBtn =
    document.querySelector('.whatsapp');

if (whatsappBtn) {

    setInterval(() => {

        whatsappBtn.animate(
            [
                { transform: 'scale(1)' },
                { transform: 'scale(1.08)' },
                { transform: 'scale(1)' }
            ],
            {
                duration: 1500
            }
        );

    }, 5000);
}


// =====================================
// MENSAJE DE BIENVENIDA
// =====================================

window.addEventListener('load', () => {

    console.log(
        'OrthoNova Clínica Dental cargada correctamente'
    );

});
